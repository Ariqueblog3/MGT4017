FOODSAVE WEBSITE PROJECT

Files:
- index.html: website content and structure
- style.css: colours, layout and mobile responsive design
- script.js: menu, food filters and demo contact form

To open:
1. Keep all three code files in the same folder.
2. Double-click index.html, or open it in a browser.

Before submitting:
- Replace sample food listings, example prices and demo contact details with accurate project information.
- Add your own FoodSave images if you have them.
- Take screenshots of your actual working pages.
- The form does not send messages. A real form needs a backend or form service.
- The food listings are examples only. There is no database, ordering, payment or live stock system.

GitHub Pages:
1. Create a GitHub repository.
2. Upload index.html, style.css and script.js.
3. Go to Settings > Pages.
4. Select the main branch and root folder, then save.
5. Wait for GitHub to publish, then open and test the live URL.
